<?php include 'includes/header.php'; ?>
<style>
    body{
        top: 40px;
    }
.container h2{
    margin-top: 80px;
    text-shadow: 2px 2px rgba(147, 146, 146, 0.73);
}
.card-title{
    text-shadow: 2px 2px rgba(75, 75, 75, 0.42);
}
.card-body{
    background-color: rgba(189, 189, 189, 0.81);
}

</style>

<link rel="stylesheet" href="assest/css/style.css">
<div class="container my-5">
    <h2 class="text-center mb-4">Membership Plans</h2>
    <div class="row">
        <!-- Basic Plan -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow animate__animated animate__fadeIn">
                <img src="..\gym_php\img\plan1.jpg" class="card-img-top" alt="Basic Plan">
                <div class="card-body text-center">
                    <h5 class="card-title">Basic Plan</h5>
                    <p class="card-text">Perfect for beginners. Access to gym equipment and basic facilities.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-check text-success me-2"></i>Access to gym equipment</li>
                        <li><i class="fas fa-check text-success me-2"></i>Locker room access</li>
                        <li><i class="fas fa-times text-danger me-2"></i>No personal trainer</li>
                    </ul>
                    <p class="card-text"><strong>₹1,999/month</strong></p>
                    <a href="payment.php?plan_id=1" class="btn btn-primary">Subscribe</a>
                </div>
            </div>
        </div>

        <!-- Premium Plan -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow animate__animated animate__fadeIn">
                <img src="..\gym_php\img\plan2.jpg" class="card-img-top" alt="Premium Plan">
                <div class="card-body text-center">
                    <h5 class="card-title">Premium Plan</h5>
                    <p class="card-text">For fitness enthusiasts. Includes personal trainer and group classes.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-check text-success me-2"></i>Access to gym equipment</li>
                        <li><i class="fas fa-check text-success me-2"></i>Personal trainer</li>
                        <li><i class="fas fa-check text-success me-2"></i>Group classes</li>
                    </ul>
                    <p class="card-text"><strong>₹4,999/6-month</strong></p>
                    <a href="payment.php?plan_id=2" class="btn btn-primary">Subscribe</a>
                </div>
            </div>
        </div>

        <!-- Ultimate Plan -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow animate__animated animate__fadeIn">
                <img src="..\gym_php\img\plan3.jpg" class="card-img-top" alt="Ultimate Plan">
                <div class="card-body text-center">
                    <h5 class="card-title">Ultimate Plan</h5>
                    <p class="card-text">For serious athletes. Includes all premium features and 24/7 access.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-check text-success me-2"></i>Access to gym equipment</li>
                        <li><i class="fas fa-check text-success me-2"></i>Personal trainer</li>
                        <li><i class="fas fa-check text-success me-2"></i>24/7 access</li>
                    </ul>
                    <p class="card-text"><strong>₹9,999/12-month</strong></p>
                    <a href="payment.php?plan_id=3" class="btn btn-primary">Subscribe</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 