<?php include 'includes/header.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
</head>
<style>
    .overlay-text {
        position: absolute;
        top: 18%;
        left: 14%;
        transform: translate(-50%, -50%);
        font-size: 35px;
        font-weight: bold;
        color: red;
        text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7);
    }

    .overlay-text strong {
        color: white;
    }

    .overlay-text1 {
        position: absolute;
        top: 45%;
        left: 15%;
        transform: translate(-50%, -50%);
        font-size: 35px;
        font-weight: bold;
        color: red;
        text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7);

    }

    .overlay-text1 strong {
        color: white;
    }

    .overlay-text3 {
        position: absolute;
        top: 68%;
        left: 14%;
        transform: translate(-50%, -50%);
        font-size: 35px;
        font-weight: bold;
        color: red;
        text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7);
    }

    .overlay-text3 strong {
        color: white;
    }

    #pera1 {
        color: white;
        font-size: 20px;
        margin-top: 13%;
        margin-left: 8%;
        margin-right: 8%;
        color: black;
    }

    #pera2 {
        color: white;
        font-size: 20px;
        margin-top: 9.5%;
        margin-left: 8%;
        margin-right: 8%;
        color: black;
    }

    #pera3 {
        color: white;
        font-size: 20px;
        margin-top: 8.3%;
        margin-left: 8%;
        margin-right: 8%;
        color: black;
    }

    .btn {
        margin-left: 7.3%;
        box-shadow: 2px 2px rgba(41, 20, 20, 0.75);
        margin-top: 2%;
    }
    @media (max-width: 768px) {
            .about-content {
                flex-direction: column;
                text-align: center;
            }
            .about-text {
                font-size: 1rem;
            }
        }
        @media (max-width: 480px) {
            h1 {
                font-size: 2rem;
            }
            .about-text {
                font-size: 0.9rem;
            }
        }
</style>

<body>

    <body>
        
        <div class="overlay-text"><strong>About </strong>Us</div>
        <p id="pera1">At our gym, we believe in empowering individuals to achieve their fitness goals through
            dedication,
            discipline, and expert guidance. Our state-of-the-art facilities and experienced trainers are here to help
            you every step of the way.</p>

        <div class="overlay-text1"><strong>Our </strong>Mission</div>
        <p id="pera2">To create a supportive and motivational environment where everyone can work towards a healthier
            lifestyle.</p>
        </div>

        <div class="overlay-text3"><strong>Our </strong>Vision</div>
        <p id="pera3">To be the leading fitness community that inspires individuals to transform their lives
            through fitness.</p>
        </div>
        <div>
            <a href="gallery.php" class="btn btn-primary">View More</a>
        </div>

    </body>
</body>

</html>

<?php include 'includes/footer.php'; ?>