<?php include 'includes/header.php'; ?>

<!-- Hero Section -->
<div class="hero-section d-flex align-items-center justify-content-center">
    <div class="text-center text-white">
        <h1 class="display-4 animate__animated animate__fadeInDown">Welcome to Our Gym</h1>
        <p class="lead animate__animated animate__fadeInUp">Transform your body, transform your life</p>
        <a href="login.php" class="btn btn-primary btn-lg animate__animated animate__fadeIn">Join Now</a>
    </div>
</div>

<!-- Features Section -->
<div class="container my-5">
    <h2 class="text-center mb-4 animate__animated animate__fadeIn">Our Features</h2>
    <div class="row">
        <div class="col-md-4 mb-4 animate__animated animate__fadeInLeft">
            <div class="card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-dumbbell fa-3x mb-3"></i>
                    <h5 class="card-title">Modern Equipment</h5>
                    <p class="card-text">State-of-the-art gym equipment for all your fitness needs.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4 animate__animated animate__fadeInUp">
            <div class="card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-users fa-3x mb-3"></i>
                    <h5 class="card-title">Expert Trainers</h5>
                    <p class="card-text">Certified trainers to guide you on your fitness journey.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4 animate__animated animate__fadeInRight">
            <div class="card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-heartbeat fa-3x mb-3"></i>
                    <h5 class="card-title">Healthy Environment</h5>
                    <p class="card-text">A clean and safe environment for your workouts.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 