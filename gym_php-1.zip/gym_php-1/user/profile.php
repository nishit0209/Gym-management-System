<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in
if (!isset($_SESSION['member_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['member_id'];
$error = '';
$success = '';

// Fetch user details
$stmt = $conn->prepare("SELECT username, email, phone FROM members WHERE member_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Get user's payment history
try {
    $stmt = $conn->prepare("
        SELECT 
            pay.payment_id,
            pay.plan_id,
            pay.amount,
            pay.payment_method,
            pay.payment_status,
            pay.payment_date,
            pl.name AS plan_name,
            pl.description AS plan_description
        FROM payments pay
        LEFT JOIN plans pl ON pay.plan_id = pl.plan_id
        WHERE pay.member_id = ?
        ORDER BY pay.payment_date DESC
    ");
    $stmt->execute([$_SESSION['member_id']]);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['error'] = "Error fetching payment history: " . $e->getMessage();
    $payments = [];
}

// Get user's current plan
try {
    $stmt = $conn->prepare("
        SELECT 
            sub.subscription_id,
            sub.start_date,
            sub.end_date,
            sub.status,
            pl.plan_id,
            pl.name AS plan_name,
            pl.description AS plan_description
        FROM subscriptions sub
        LEFT JOIN plans pl ON sub.plan_id = pl.plan_id
        WHERE sub.member_id = ? AND sub.status = 'active'
        ORDER BY sub.end_date DESC
        LIMIT 1
    ");
    $stmt->execute([$_SESSION['member_id']]);
    $userPlan = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['error'] = "Error fetching current plan: " . $e->getMessage();
    $userPlan = [];
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $phone = trim($_POST['phone']);

    if (empty($username) || empty($phone)) {
        $error = 'All fields are required.';
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $error = 'Phone number must be 10 digits.';
    } else {
        // Update user profile
        $stmt = $conn->prepare("UPDATE members SET username = ?, phone = ? WHERE member_id = ?");
        if ($stmt->execute([$username, $phone, $user_id])) {
            $success = 'Profile updated successfully!';
            // Refresh user data
            $stmt = $conn->prepare("SELECT username, email, phone FROM members WHERE member_id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();
        } else {
            $error = 'Failed to update profile. Please try again.';
        }
    }
}

// Display plan details
if (isset($userPlan) && !empty($userPlan)) {
    echo '<div class="card mt-4">
            <div class="card-header">
                <h5>Current Plan</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Plan Name:</strong> ' . htmlspecialchars($userPlan['plan_name'] ?? 'N/A') . '</p>
                        <p><strong>Description:</strong> ' . htmlspecialchars($userPlan['plan_description'] ?? 'No description available') . '</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Start Date:</strong> ' . date('M d, Y', strtotime($userPlan['start_date'])) . '</p>
                        <p><strong>End Date:</strong> ' . date('M d, Y', strtotime($userPlan['end_date'])) . '</p>
                    </div>
                
        </div>';
} 

// Display plan status
// if (isset($userPlan['status'])) {
//     $status = $userPlan['status'];
//     $statusClass = ($status === 'active') ? 'text-success' : 'text-warning';
//     echo '<p><strong>Status:</strong> <span class="' . $statusClass . '">' . ucfirst($status) . '</span></p>';
// } else {
//     echo '<p><strong>Status:</strong> <span class="text-secondary">Unknown</span></p>';
// }

// Display payment status
// if (isset($payment['payment_status'])) {
//     $paymentStatus = $payment['payment_status'];
//     $statusClass = ($paymentStatus === 'completed') ? 'text-success' : 'text-warning';
//     echo '<td><span class="' . $statusClass . '">' . ucfirst($paymentStatus) . '</span></td>';
// } else {
//     echo '<td><span class="text-secondary">Unknown</span></td>';
// }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Website</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- <style>
        body {
        background-color:; /* Soft blue-gray */
        font-family: Arial, sans-serif;
        /* margin: 0; */
        margin-left: 50px;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .container {
        max-width: 100%;
        width: 100%;
        display: flex;
        justify-content: space-between;
        gap: 10px;
    }

    .card {
        background-color: #d8baba; /* Soft pink */
        padding: 15px;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .col-md-8,
    .col-md-4 {
        flex: 1;
    }

    .card-title {
        font-size: 24px;
        font-weight: bold;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
    }

    .form-label {
        font-weight: bold;
    }

    .form-control {
        border-radius: 5px;
        padding: 10px;
        border: 1px solid #ccc;
    }

    .btn-primary {
        background-color:;
        border: none;
        padding: 10px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    .btn-primary:hover {
        background-colo;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    table, th, td {
        border: 1px solid #ddd;
        text-align: left;
    }

    th, td {
        padding: 10px;
    }

    th {
        background-color: #f4f4f4;
    }

    @media (max-width: 768px) {
        .container {
            flex-direction: column;
            align-items: center;
        }

        .col-md-8,
        .col-md-4 {
            width: 100%;
        }

        table {
            display: block;
            overflow-x: auto;
        }
    } -->
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="../index.php">
        <img src="../img/logo.png" alt="Gym Logo" width="140" height="35" class="d-inline-block align-text-top">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="../plans.php">Plans</a></li>
                <li class="nav-item"><a class="nav-link" href="../gallery.php">Gallery</a></li>
                <li class="nav-item"><a class="nav-link" href="../contact.php">Contact</a></li>
            </ul>
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <?php if(isset($_SESSION['member_id'])): ?>
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="../login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="../register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="container my-5">
    <div class="row">
        <div class="col-md-8">
            <div class="card shadow animate__animated animate__fadeIn">
                <div class="card-body">
                    <h2 class="card-title mb-4">Profile</h2>
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <form action="profile.php" method="POST">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo $user['username']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" value="<?php echo $user['email']; ?>" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo $user['phone']; ?>" required>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow animate__animated animate__fadeIn">
                <div class="card-body">
                    <h2 class="card-title mb-4">Purchased Plans</h2>
                    <?php if (empty($payments)): ?>
                        <p>No plans purchased yet.</p>
                        <?php else: ?>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Plan Name</th>
                                            <th>Description</th>
                                            <th>Amount</th>
                                            <th>Payment Method</th>
                                            <th>Status</th>
                                            <th>Payment Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($payments as $payment): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($payment['plan_name']); ?></td>
                                                <td><?php echo htmlspecialchars($payment['plan_description']); ?></td>
                                                <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                                                <td><?php echo htmlspecialchars($payment['payment_method']); ?></td>
                                                <td><?php echo htmlspecialchars($payment['payment_status']); ?></td>
                                                <td><?php echo htmlspecialchars($payment['payment_date']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>
                </div>
        </div>
    </div>
</div>
</body>

