<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in


// Fetch user's purchased plan details
$stmt = $conn->prepare("
    SELECT 
        p.name AS plan_name, 
        p.description AS plan_description, 
        p.price AS plan_price, 
        py.payment_method, 
        py.payment_status, 
        py.payment_date
    FROM 
        payments py
    JOIN 
        plans p ON py.plan_id = p.plan_id
    WHERE 
        py.member_id = ?
    ORDER BY 
        py.payment_date DESC
");
$stmt->execute([$_SESSION['member_id']]);
$purchased_plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Plan</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>User Dashboard</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="user_details.php" class="text-white"><i class="fas fa-user me-2"></i>My Details</a>
            </li>
            <li class="active">
                <a href="buy_plan.php" class="text-white"><i class="fas fa-shopping-cart me-2"></i>Buy Plan</a>
            </li>
            <li>
                <a href="progress_report.php" class="text-white"><i class="fas fa-chart-line me-2"></i>Progress Report</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>My Purchased Plans</h2>
            <div class="table-responsive mt-4">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Plan Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                            <th>Payment Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($purchased_plans)): ?>
                            <tr>
                                <td colspan="6" class="text-center">No purchased plans found.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($purchased_plans as $plan): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($plan['plan_name']); ?></td>
                                    <td><?php echo htmlspecialchars($plan['plan_description']); ?></td>
                                    <td>₹<?php echo htmlspecialchars($plan['plan_price']); ?></td>
                                    <td><?php echo htmlspecialchars($plan['payment_method']); ?></td>
                                    <td><?php echo htmlspecialchars($plan['payment_status']); ?></td>
                                    <td><?php echo htmlspecialchars($plan['payment_date']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 