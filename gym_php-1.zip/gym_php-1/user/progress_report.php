<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in


// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $previous_height = $_POST['previous_height'];
    $previous_weight = $_POST['previous_weight'];
    $current_height = $_POST['current_height'];
    $current_weight = $_POST['current_weight'];
    $progress_months = $_POST['progress_months'];

    // Insert progress report into database
    $stmt = $conn->prepare("
        INSERT INTO member_progress (member_id, previous_height, previous_weight, height, weight, progress_months)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$_SESSION['member_id'], $previous_height, $previous_weight, $current_height, $current_weight, $progress_months]);

    // Redirect to dashboard with success message
    $_SESSION['success'] = "Progress report submitted successfully!";
    header('Location: dashboard.php');
    exit();
}

// Fetch previous progress reports
$stmt = $conn->prepare("
    SELECT previous_height, previous_weight, height, weight, progress_months, report_date
    FROM member_progress
    WHERE member_id = ?
    ORDER BY report_date DESC
");
$stmt->execute([$_SESSION['member_id']]);
$previous_reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progress Report</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>User Dashboard</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="user_details.php" class="text-white"><i class="fas fa-user me-2"></i>My Details</a>
            </li>
            <li>
                <a href="buy_plan.php" class="text-white"><i class="fas fa-shopping-cart me-2"></i>Buy Plan</a>
            </li>
            <li class="active">
                <a href="progress_report.php" class="text-white"><i class="fas fa-chart-line me-2"></i>Progress Report</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Progress Report</h2>

            <!-- Previous Progress Reports -->
            <div class="mt-4">
                <h4>Previous Reports</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Previous Height (cm)</th>
                                <th>Previous Weight (kg)</th>
                                <th>Current Height (cm)</th>
                                <th>Current Weight (kg)</th>
                                <th>Progress Months</th>
                                <th>Report Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($previous_reports)): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No previous reports found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($previous_reports as $report): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($report['previous_height']); ?></td>
                                        <td><?php echo htmlspecialchars($report['previous_weight']); ?></td>
                                        <td><?php echo htmlspecialchars($report['height']); ?></td>
                                        <td><?php echo htmlspecialchars($report['weight']); ?></td>
                                        <td><?php echo htmlspecialchars($report['progress_months']); ?></td>
                                        <td><?php echo htmlspecialchars($report['report_date']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Progress Report Form -->
            <div class="mt-4">
                <h4>Submit New Report</h4>
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Previous Measurements</h5>
                            <div class="mb-3">
                                <label for="previous_height" class="form-label">Previous Height (cm)</label>
                                <input type="number" class="form-control" id="previous_height" name="previous_height" required>
                            </div>
                            <div class="mb-3">
                                <label for="previous_weight" class="form-label">Previous Weight (kg)</label>
                                <input type="number" class="form-control" id="previous_weight" name="previous_weight" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h5>Current Measurements</h5>
                            <div class="mb-3">
                                <label for="current_height" class="form-label">Current Height (cm)</label>
                                <input type="number" class="form-control" id="current_height" name="current_height" required>
                            </div>
                            <div class="mb-3">
                                <label for="current_weight" class="form-label">Current Weight (kg)</label>
                                <input type="number" class="form-control" id="current_weight" name="current_weight" required>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="progress_months" class="form-label">Progress Months</label>
                        <input type="number" class="form-control" id="progress_months" name="progress_months" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 