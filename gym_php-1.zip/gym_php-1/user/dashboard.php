<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in
if (!isset($_SESSION['member_id'])) {
    header('Location: ../login.php');
    exit();
}

// Get count of new announcements (last 7 days)
$stmt = $conn->prepare("
    SELECT COUNT(*) as new_announcements 
    FROM announcements 
    WHERE status = 'active' 
    AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
");
$stmt->execute();
$new_announcements = $stmt->fetch()['new_announcements'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>User Dashboard</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="user_details.php" class="text-white"><i class="fas fa-user me-2"></i>My Details</a>
            </li>
            <li>
                <a href="buy_plan.php" class="text-white"><i class="fas fa-shopping-cart me-2"></i>Buy Plan</a>
            </li>
            <li>
                <a href="progress_report.php" class="text-white"><i class="fas fa-chart-line me-2"></i>Progress Report</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
            <p>This is your dashboard. Use the sidebar to navigate.</p>
        </div>

        <!-- Announcements Card -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-bullhorn me-2"></i>Recent Announcements
                        <?php if ($new_announcements > 0): ?>
                            <span class="badge bg-primary"><?php echo $new_announcements; ?> New</span>
                        <?php endif; ?>
                    </h5>
                    <a href="announcements.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php
                    // Fetch recent announcements
                    $stmt = $conn->prepare("
                        SELECT * FROM announcements 
                        WHERE status = 'active' 
                        ORDER BY created_at DESC 
                        LIMIT 3
                    ");
                    $stmt->execute();
                    $recent_announcements = $stmt->fetchAll();
                    
                    if (!empty($recent_announcements)):
                        // Get total number of announcements for loop control
                        $total_announcements = count($recent_announcements);
                        $counter = 0;
                        
                        foreach ($recent_announcements as $announcement):
                            $counter++;
                            $isNew = (time() - strtotime($announcement['created_at'])) < (7 * 24 * 60 * 60);
                    ?>
                        <div class="announcement-preview mb-3">
                            <h6>
                                <?php echo htmlspecialchars($announcement['title']); ?>
                                <?php if ($isNew): ?>
                                    <span class="badge bg-primary">New</span>
                                <?php endif; ?>
                            </h6>
                            <p class="small text-muted mb-1">
                                <?php echo date('M d, Y', strtotime($announcement['created_at'])); ?>
                            </p>
                            <p class="mb-0">
                                <?php echo htmlspecialchars(substr($announcement['content'], 0, 100)) . '...'; ?>
                                <a href="announcements.php" class="text-primary">Read more</a>
                            </p>
                        </div>
                        <?php 
                            // Add divider if not the last announcement
                            if ($counter < $total_announcements): 
                        ?>
                            <hr>
                        <?php 
                            endif;
                        endforeach;
                    else:
                    ?>
                        <p class="text-center text-muted mb-0">No announcements available.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 