<?php
session_start();
include '../includes/db.php';

// Check if user is logged in

// Fetch active announcements
try {
    $stmt = $conn->prepare("SELECT * FROM announcements WHERE status = 'active' ORDER BY created_at DESC");
    $stmt->execute();
    $announcements = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Error fetching announcements: " . $e->getMessage();
    $announcements = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - Gym Management System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .announcement-card {
            transition: transform 0.2s;
            margin-bottom: 20px;
        }
        
        .announcement-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .announcement-date {
            font-size: 0.9rem;
            color: #6c757d;
        }

        .announcement-badge {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .announcement-content {
            color: #555;
            line-height: 1.6;
        }

        .new-announcement {
            border-left: 4px solid #007bff;
        }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>User Dashboard</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="user_details.php" class="text-white"><i class="fas fa-user me-2"></i>My Details</a>
            </li>
            <li>
                <a href="buy_plan.php" class="text-white"><i class="fas fa-shopping-cart me-2"></i>Buy Plan</a>
            </li>
            <li>
                <a href="progress_report.php" class="text-white"><i class="fas fa-chart-line me-2"></i>Progress Report</a>
            </li>
            <li>
                <a href="progress_report.php" class="text-white"><i class="fa fa-bullhorn me-2"></i>Annoucement</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>


        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1><i class="fas fa-bullhorn me-2"></i>Announcements</h1>
            </div>

            <?php if (empty($announcements)): ?>
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>No announcements available at this time.
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($announcements as $announcement): 
                        $isNew = (time() - strtotime($announcement['created_at'])) < (7 * 24 * 60 * 60); // 7 days
                    ?>
                        <div class="col-12 mb-4">
                            <div class="card announcement-card <?php echo $isNew ? 'new-announcement' : ''; ?>">
                                <?php if ($isNew): ?>
                                    <div class="announcement-badge">
                                        <span class="badge bg-primary">New</span>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <?php echo htmlspecialchars($announcement['title']); ?>
                                    </h5>
                                    
                                    <p class="announcement-date mb-3">
                                        <i class="fas fa-calendar-alt me-1"></i>
                                        Posted: <?php echo date('F d, Y', strtotime($announcement['created_at'])); ?>
                                        <?php if ($announcement['updated_at'] != $announcement['created_at']): ?>
                                            <span class="ms-2">
                                                <i class="fas fa-edit me-1"></i>
                                                Updated: <?php echo date('F d, Y', strtotime($announcement['updated_at'])); ?>
                                            </span>
                                        <?php endif; ?>
                                    </p>
                                    
                                    <div class="announcement-content">
                                        <?php 
                                        // Convert URLs to clickable links
                                        $content = preg_replace('/(https?:\/\/[^\s]+)/', '<a href="$1" target="_blank">$1</a>', htmlspecialchars($announcement['content']));
                                        // Convert line breaks to <br> tags
                                        echo nl2br($content);
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 