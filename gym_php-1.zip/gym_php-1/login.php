<?php
session_start();
include 'includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        // Fetch member from database
        $stmt = $conn->prepare("SELECT username,member_id, password FROM members WHERE email = ?");
        $stmt->execute([$email]);
        $member = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($member && password_verify($password, $member['password'])) {
            // Set session variables
            $_SESSION['member_id'] = $member['member_id'];
            $_SESSION['username']=$member['username'];
            $_SESSION['logged_in'] = true;

            // Redirect to dashboard
            header("Location: user/profile.php");
            exit();
        } else {
            $error = 'Invalid email or password.';
        }
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>

<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #111;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #7b90a4;
        }
        .container {
            margin-top: 45px;
            width: 100%;
            max-width: 450px;
            padding: 25px;
            background:rgba(237, 204, 204, 0.82);
            border-radius: 15px;
            box-shadow: 10px 10px 10px rgba(94, 91, 91, 0.76);
            text-align: center;
        }
        h1 {
            font-size: 2rem;
            margin-bottom: 20px;
            text-shadow: 2px 2px rgba(128, 124, 124, 0.76);
        }
        .form-group {
            position: relative;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            background: white;
            border-radius: 5px;
            overflow: hidden;
        }
        .form-group i {
            padding: 10px;
            background:rgba(255, 0, 0, 0.57);
            color: black;
            min-width: 40px;
            text-align: center;
            border-radius: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 1rem;
            border: none;
            outline: none;
        }
        .btn {
            width: 100%;
            padding: 10px;
            font-size: 1.2rem;
            background:rgba(162, 0, 0, 0.7);
            color: black;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background:rgba(255, 0, 0, 0.62);
        }
        @media (max-width: 480px) {
            h1 {
                font-size: 1.8rem;
            }
            .form-group input {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>LOGIN</h1>
        <form action="login.php" method="POST">
            <div class="form-group">
                <i class="fas fa-envelope"></i>
                <input type="email" placeholder="Email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <i class="fas fa-lock"></i>
                <input type="password" placeholder="Password" id="password" name="password" required>
            </div>
            <a href="forget_password.php">Forget password?</a>
            <p>Don't have an account? <a href="register.php">Sign up here</a></p>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>
</body>
</html>

 