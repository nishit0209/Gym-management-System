<?php include 'includes/header.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Gallery</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #7b90a4;
            color: white;
            text-align: center;
        }
        h1 {
            font-size: 2rem;
            padding: 20px;
        }
        .gallery-container {
            max-width: 1200px;
            margin: 20px auto;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
            padding: 13px;
        }
        .gallery-item {
            position: relative;
            cursor: pointer;
            overflow: hidden;
            border-radius: 10px;
        }
        .gallery-item img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }
        .gallery-item:hover img {
            transform: scale(1.1);
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .gallery-item:hover .overlay {
            opacity: 1;
        }
        .overlay h3 {
            color: #fff;
            font-size: 1.2rem;
            text-align: center;
            padding: 10px;
        }
        .lightbox {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            display: none;
            padding: 20px;
        }
        .lightbox img {
            max-width: 90%;
            max-height: 80%;
            border-radius: 10px;
        }
        .lightbox .close {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }
        @media (max-width: 768px) {
            .gallery-container {
                grid-template-columns: repeat(2, 1fr);
                padding: 10px;
            }
            .overlay h3 {
                font-size: 1rem;
            }
        }
        @media (max-width: 480px) {
            h1 {
                font-size: 1.5rem;
            }
            .gallery-container {
                grid-template-columns: repeat(1, 1fr);
            }
            .overlay h3 {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <h1>Gym Gallery</h1>
    <div class="gallery-container">
        <div class="gallery-item" onclick="openLightbox('..\gym_php\img\gallery2.jpg')">
            <img src="..\gym_php\img\gallery2.jpg" alt="Gym Equipment">
            <div class="overlay"><h3>Gym Equipment</h3></div>
        </div>
        <div class="gallery-item" onclick="openLightbox('..\gym_php\img\gallery1.jpg')">
            <img src="..\gym_php\img\gallery1.jpg" alt="Workout Area">
            <div class="overlay"><h3>Workout Area</h3></div>
        </div>
        <div class="gallery-item" onclick="openLightbox('..\gym_php\img\gallery3.jpg')">
            <img src="..\gym_php\img\gallery3.jpg" alt="Cardio Section">
            <div class="overlay"><h3>Cardio Section</h3></div>
        </div>
        <div class="gallery-item" onclick="openLightbox('..\gym_php\img\gallery5.jpg')">
            <img src="..\gym_php\img\gallery5.jpg" alt="Strength Training">
            <div class="overlay"><h3>Strength Training</h3></div>
        </div>
        <div class="gallery-item" onclick="openLightbox('..\gym_php\img\gallery4.jpg')">
            <img src="..\gym_php\img\gallery4.jpg" alt="Personal Training">
            <div class="overlay"><h3>Personal Training</h3></div>
        </div>
        <div class="gallery-item" onclick="openLightbox('..\gym_php\img\gallery6.jpg')">
            <img src="..\gym_php\img\gallery6.jpg" alt="Group Classes">
            <div class="overlay"><h3>Group Classes</h3></div>
        </div>
    </div>
    
    <div class="lightbox" id="lightbox">
        <span class="close" onclick="closeLightbox()">&times;</span>
        <img id="lightbox-img" src="" alt="">
    </div>
    
    <script>
        function openLightbox(imageSrc) {
            document.getElementById("lightbox-img").src = imageSrc;
            document.getElementById("lightbox").style.display = "flex";
        }
        function closeLightbox() {
            document.getElementById("lightbox").style.display = "none";
        }
    </script>
</body>
</html>


<?php include 'includes/footer.php'; ?>