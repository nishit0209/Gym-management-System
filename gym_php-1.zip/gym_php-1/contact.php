<?php include 'includes/header.php'; ?>
<style>
   .container{
    height: 575px;
    overflow-y: hidden;
   }

</style>

<?php include 'includes/footer.php'; ?>