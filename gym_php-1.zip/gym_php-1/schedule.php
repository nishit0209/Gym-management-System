<?php 
include 'includes/db.php';
include 'includes/header.php'; 
try {
    $stmt = $conn->prepare("SELECT * FROM schedule ORDER BY day, start_time");
    $stmt->execute();
    $schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error fetching schedule: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly Workout Routine</title>
    <style>
        body{
            background-color: #7b90a4;
        }
        .schedule-container {
            background: white;
            padding: 30px;
            margin-top: 90px;
            margin-left: 30px;
            margin-right: 30px;
            margin-bottom: 30px;
            line-height: 3vh;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            box-shadow:  0px 4px 10px rgba(0, 0, 0, 0.1);
            background-color: darkgrey;
        }
        h1 {
            color: black;
            margin-bottom: 20px;
            text-align: center;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7);
            
        }
        table {
            border-collapse: collapse;
            margin-top: 30px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: rgba(0, 0, 0, 0.84);
            color: white;

        }
        tr:nth-child(even) {
            background: grey;
        }
        @media (max-width: 768px) {
            .schedule-container {
                width: 95%;
                padding: 15px;
            }
            th, td {
                padding: 8px;
                font-size: 14px;
            }
        }
        @media (max-width: 480px) {
            th, td {
                padding: 6px;
                font-size: 12px;
            }
            h1 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="schedule-container">
        <h1>WEEKLY WORKOUT & DIET PLAN</h1>
        <table width=100%>
            <tr>
                <th>Day</th>
                <th>Time</th>
                <th>Workout</th>
                <th>Exercise</th>
                <th>Sets & Reps</th>
                <th>Diet</th>
            </tr>
            <?php if (!empty($schedule)): ?>
                <?php foreach ($schedule as $class): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($class['day']); ?></td>
                                        <td><?php echo date('h:i A', strtotime($class['start_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($class['workout']); ?></td>
                                        <td><?php echo htmlspecialchars($class['exercise']); ?></td>
                                        <td><?php echo htmlspecialchars($class['reps']); ?> mins</td>
                                        <td><?php echo htmlspecialchars($class['diet']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
        </table>
    </div>
</body>
</html>

<?php include 'includes/footer.php'; ?>
