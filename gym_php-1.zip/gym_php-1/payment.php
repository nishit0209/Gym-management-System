<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

// Redirect if not logged in
if (!isset($_SESSION['member_id'])) {
    header("Location: login.php");
    exit();
}

// Get plan details if coming from plan selection
$plan_id = isset($_GET['plan_id']) ? $_GET['plan_id'] : null;
if ($plan_id) {
    $stmt = $conn->prepare("SELECT * FROM plans WHERE plan_id = ?");
    $stmt->execute([$plan_id]);
    $plan = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$plan) {
        $_SESSION['error'] = "Invalid plan selected";
        header("Location: plans.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Gym Management System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .payment-method-card {
            cursor: pointer;
            transition: all 0.3s;
        }
        .payment-method-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .payment-method-card.selected {
            border-color: #0d6efd;
            background-color: #f8f9fa;
        }
        #card-element {
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 4px;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Payment Details</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger">
                            <?php 
                            echo $_SESSION['error'];
                            unset($_SESSION['error']);
                            ?>
                        </div>
                    <?php endif; ?>

                    <form id="payment-form" action="process_payment.php" method="POST" class="needs-validation" novalidate>
                        <?php if (isset($plan)): ?>
                            <input type="hidden" name="plan_id" value="<?php echo $plan['plan_id']; ?>">
                            <input type="hidden" name="amount" value="<?php echo $plan['price']; ?>">
                            <div class="alert alert-info">
                                <h5>Plan Details:</h5>
                                <p class="mb-0">
                                    <?php echo htmlspecialchars($plan['name']); ?> - 
                                    ₹<?php echo number_format($plan['price'], 2); ?>
                                </p>
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <label class="form-label">Amount (₹)</label>
                                <input type="number" name="amount" class="form-control" required min="1" step="0.01">
                            </div>
                        <?php endif; ?>

                        <!-- Payment Method Selection -->
                        <div class="mb-4">
                            <label class="form-label">Select Payment Method</label>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <div class="card payment-method-card" data-method="credit_card">
                                        <div class="card-body text-center">
                                            <i class="fas fa-credit-card fa-2x mb-2"></i>
                                            <h6 class="mb-0">Credit/Debit Card</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="card payment-method-card" data-method="upi">
                                        <div class="card-body text-center">
                                            <i class="fas fa-mobile-alt fa-2x mb-2"></i>
                                            <h6 class="mb-0">UPI Payment</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="card payment-method-card" data-method="cash">
                                        <div class="card-body text-center">
                                            <i class="fas fa-money-bill-wave fa-2x mb-2"></i>
                                            <h6 class="mb-0">Cash Payment</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="payment_method" id="payment_method" required>
                        </div>

                        <!-- Credit Card Form -->
                        <div id="credit-card-form" style="display: none;">
                            <div class="mb-3">
                                <label class="form-label">Card Number</label>
                                <input type="text" name="card_number" class="form-control" pattern="[0-9]{16}" maxlength="16" placeholder="1234 5678 9012 3456">
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Expiry Date</label>
                                    <input type="text" name="card_expiry" class="form-control" pattern="(0[1-9]|1[0-2])\/([0-9]{2})" placeholder="MM/YY">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">CVV</label>
                                    <input type="text" name="card_cvv" class="form-control" pattern="[0-9]{3,4}" maxlength="4" placeholder="123">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Card Holder Name</label>
                                <input type="text" name="card_holder" class="form-control" placeholder="John Doe">
                            </div>
                        </div>

                        <!-- UPI Form -->
                        <div id="upi-form" style="display: none;">
                            <div class="mb-3">
                                <label class="form-label">UPI ID</label>
                                <input type="text" name="upi_id" class="form-control" placeholder="username@upi">
                            </div>
                        </div>

                        <!-- Cash Payment Instructions -->
                        <div id="cash-form" style="display: none;">
                            <div class="alert alert-info">
                                <h5>Cash Payment Instructions</h5>
                                <p>
                                    Please visit our gym reception to complete your payment in cash.<br>
                                    Our reception hours are:<br>
                                    - Monday to Friday: 6:00 AM to 10:00 PM<br>
                                    - Saturday: 7:00 AM to 8:00 PM<br>
                                    - Sunday: 8:00 AM to 6:00 PM
                                </p>
                                <p>
                                    Bring this reference number with you: <strong><?php echo uniqid('CASH-'); ?></strong>
                                </p>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100" id="submit-button">
                            Pay ₹<?php echo isset($plan) ? number_format($plan['price'], 2) : '0.00'; ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const paymentCards = document.querySelectorAll('.payment-method-card');
    const paymentMethodInput = document.getElementById('payment_method');
    const creditCardForm = document.getElementById('credit-card-form');
    const upiForm = document.getElementById('upi-form');
    const cashForm = document.getElementById('cash-form');
    const form = document.getElementById('payment-form');

    // Payment method selection
    paymentCards.forEach(card => {
        card.addEventListener('click', function() {
            const method = this.dataset.method;
            
            // Remove selected class from all cards
            paymentCards.forEach(c => c.classList.remove('selected'));
            // Add selected class to clicked card
            this.classList.add('selected');
            
            // Set payment method
            paymentMethodInput.value = method;
            
            // Show/hide appropriate form
            creditCardForm.style.display = method === 'credit_card' ? 'block' : 'none';
            upiForm.style.display = method === 'upi' ? 'block' : 'none';
            cashForm.style.display = method === 'cash' ? 'block' : 'none';
        });
    });

    // Form validation
    form.addEventListener('submit', function(event) {
        if (!paymentMethodInput.value) {
            alert('Please select a payment method');
            event.preventDefault();
            return;
        }

        if (paymentMethodInput.value === 'credit_card') {
            const cardNumber = document.querySelector('[name="card_number"]').value;
            const cardExpiry = document.querySelector('[name="card_expiry"]').value;
            const cardCvv = document.querySelector('[name="card_cvv"]').value;
            const cardHolder = document.querySelector('[name="card_holder"]').value;

            if (!cardNumber || !cardExpiry || !cardCvv || !cardHolder) {
                alert('Please fill in all card details');
                event.preventDefault();
                return;
            }

            // Validate card number format
            if (!/^\d{16}$/.test(cardNumber)) {
                alert('Please enter a valid 16-digit card number');
                event.preventDefault();
                return;
            }

            // Validate expiry date format
            if (!/^(0[1-9]|1[0-2])\/([0-9]{2})$/.test(cardExpiry)) {
                alert('Please enter a valid expiry date (MM/YY)');
                event.preventDefault();
                return;
            }

            // Validate CVV format
            if (!/^\d{3,4}$/.test(cardCvv)) {
                alert('Please enter a valid CVV');
                event.preventDefault();
                return;
            }
        } else if (paymentMethodInput.value === 'upi') {
            const upiId = document.querySelector('[name="upi_id"]').value;
            
            if (!upiId) {
                alert('Please enter your UPI ID');
                event.preventDefault();
                return;
            }

            // Validate UPI ID format
            if (!/^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/.test(upiId)) {
                alert('Please enter a valid UPI ID');
                event.preventDefault();
                return;
            }
        }
    });
});
</script>
</body>
</html> 