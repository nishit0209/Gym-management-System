<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}


// Fetch total users
$stmt = $conn->prepare("SELECT COUNT(*) AS total_users FROM members");
$stmt->execute();
$total_users = $stmt->fetch()['total_users'];

// Fetch total staff
$stmt = $conn->prepare("SELECT COUNT(*) AS total_staff FROM staff");
$stmt->execute();
$total_staff = $stmt->fetch()['total_staff'];

// Fetch total payments
$stmt = $conn->prepare("SELECT SUM(amount) AS total_payments FROM payments");
$stmt->execute();
$total_payments = $stmt->fetch()['total_payments'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Dashboard</h3>
        </div>
        <ul class="list-unstyled components">
            <li class="active">
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="manage_members.php" class="text-white"><i class="fas fa-users me-2"></i>Manage Members</a>
            </li>
            <li>
                <a href="manage_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>Manage Plans</a>
            </li>
            <li>
                <a href="manage_staff.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage Staff</a>
            </li>
            <li>
                <a href="manage_payments.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage payment</a>
            </li>
            <li class="active">
                <a href="manage_reports.php" class="text-white"><i class="fas fa-chart-bar me-2"></i>Manage Reports</a>
            </li>
            <li class="active">
                <a href="view_announcement.php" class="text-white"><i class="fa fa-bullhorn me-2"></i>Annoucement</a>
            </li>
            <li class="active">
                <a href="schedule.php" class="text-white"><i class="fa fa-calendar me-2"></i>Schedule</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Welcome to the Admin Dashboard</h2>
            <div class="row mt-4">
                <!-- Total Users Card -->
                <div class="col-md-4">
                    <div class="card bg-primary text-white">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-users me-2"></i>Total Users</h5>
                            <p class="card-text display-4"><?php echo $total_users; ?></p>
                        </div>
                    </div>
                </div>

                <!-- Total Staff Card -->
                <div class="col-md-4">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-user-tie me-2"></i>Total Staff</h5>
                            <p class="card-text display-4"><?php echo $total_staff; ?></p>
                        </div>
                    </div>
                </div>

                <!-- Total Payments Card -->
                <div class="col-md-4">
                    <div class="card bg-danger text-white">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-money-bill-wave me-2"></i>Total Payments</h5>
                            <p class="card-text display-4">₹<?php echo number_format($total_payments, 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 