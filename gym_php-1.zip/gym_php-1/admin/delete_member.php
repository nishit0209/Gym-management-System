<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin


// Delete member
if (isset($_GET['id'])) {
    $member_id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM members WHERE member_id = ?");
    if ($stmt->execute([$member_id])) {
        header('Location: manage_members.php');
        exit();
    } else {
        echo "Failed to delete member.";
    }
} else {
    header('Location: manage_members.php');
    exit();
}
?> 