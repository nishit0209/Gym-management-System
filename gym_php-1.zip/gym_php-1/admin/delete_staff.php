<?php
include '../includes/db.php';

// Delete staff
if (isset($_GET['id'])) {
    $staff_id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM staff WHERE staff_id = ?");
    if ($stmt->execute([$staff_id])) {
        header('Location: manage_staff.php');
        exit();
    } else {
        echo "Failed to delete staff.";
    }
} else {
    header('Location: manage_staff.php');
    exit();
}
?> 