<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin


// Initialize search term
$search_term = '';
$payments = [];

// Check if search form is submitted
if (isset($_GET['search'])) {
    $search_term = trim($_GET['search']);
    
    // Fetch payments filtered by member name
    $stmt = $conn->prepare("
        SELECT p.payment_id, p.amount, p.payment_method, p.payment_status, p.payment_date,
               m.username AS member_name, pl.name AS plan_name
        FROM payments p
        JOIN members m ON p.member_id = m.member_id
        JOIN plans pl ON p.plan_id = pl.plan_id
        WHERE m.username LIKE :search
        ORDER BY p.payment_date DESC
    ");
    $stmt->execute([':search' => '%' . $search_term . '%']);
    $payments = $stmt->fetchAll();
} else {
    // Fetch all payments if no search term
    $stmt = $conn->prepare("
        SELECT p.payment_id, p.amount, p.payment_method, p.payment_status, p.payment_date,
               m.username AS member_name, pl.name AS plan_name
        FROM payments p
        JOIN members m ON p.member_id = m.member_id
        JOIN plans pl ON p.plan_id = pl.plan_id
        ORDER BY p.payment_date DESC
    ");
    $stmt->execute();
    $payments = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Payments</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="manage_members.php" class="text-white"><i class="fas fa-users me-2"></i>Manage Members</a>
            </li>
            <li>
                <a href="manage_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>Manage Plans</a>
            </li>
            <li>
                <a href="manage_staff.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage Staff</a>
            </li>
            <li class="active">
                <a href="manage_payments.php" class="text-white"><i class="fas fa-money-bill-wave me-2"></i>Manage Payments</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Manage Payments</h2>
            
            <!-- Search Form -->
            <form method="GET" class="mb-3">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Search by member name" value="<?php echo htmlspecialchars($search_term); ?>">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
                    <?php if ($search_term): ?>
                        <a href="manage_payments.php" class="btn btn-secondary"><i class="fas fa-times"></i> Clear</a>
                    <?php endif; ?>
                </div>
            </form>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Payment ID</th>
                        <th>Member Name</th>
                        <th>Plan Name</th>
                        <th>Amount</th>
                        <th>Payment Method</th>
                        <th>Status</th>
                        <th>Payment Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($payments) > 0): ?>
                        <?php foreach ($payments as $payment): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($payment['payment_id']); ?></td>
                                <td><?php echo htmlspecialchars($payment['member_name']); ?></td>
                                <td><?php echo htmlspecialchars($payment['plan_name']); ?></td>
                                <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                                <td><?php echo htmlspecialchars($payment['payment_method']); ?></td>
                                <td><?php echo htmlspecialchars($payment['payment_status']); ?></td>
                                <td><?php echo htmlspecialchars($payment['payment_date']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">No payments found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 