<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin


// Initialize message variables
$success_msg = '';
$error_msg = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                try {
                    $stmt = $conn->prepare("INSERT INTO announcements (title, content) VALUES (?, ?)");
                    $stmt->execute([$_POST['title'], $_POST['content']]);
                    $success_msg = "Announcement added successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Error adding announcement: " . $e->getMessage();
                }
                break;
                
            case 'update':
                if (isset($_POST['id']) && is_numeric($_POST['id'])) {
                    try {
                        $stmt = $conn->prepare("UPDATE announcements SET title = ?, content = ?, status = ? WHERE id = ?");
                        $stmt->execute([$_POST['title'], $_POST['content'], $_POST['status'], $_POST['id']]);
                        $success_msg = "Announcement updated successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Error updating announcement: " . $e->getMessage();
                    }
                }
                break;
                
            case 'delete':
                if (isset($_POST['id']) && is_numeric($_POST['id'])) {
                    try {
                        $stmt = $conn->prepare("DELETE FROM announcements WHERE id = ?");
                        $stmt->execute([$_POST['id']]);
                        $success_msg = "Announcement deleted successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Error deleting announcement: " . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Fetch all announcements
try {
    $stmt = $conn->prepare("SELECT * FROM announcements ORDER BY created_at DESC");
    $stmt->execute();
    $announcements = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Error fetching announcements: " . $e->getMessage();
    $announcements = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Announcements</title>
    <!-- Include your CSS files here -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>

        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="nav-link-custom">
                    <i class="fas fa-home me-2"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="manage_members.php" class="nav-link-custom">
                    <i class="fas fa-users me-2"></i>
                    Members
                </a>
            </li>
            <li>
                <a href="manage_plans.php" class="nav-link-custom">
                    <i class="fas fa-list-alt me-2"></i>
                    Plans
                </a>
            </li>
            <li>
                <a href="manage_staff.php" class="nav-link-custom">
                    <i class="fas fa-user-tie me-2"></i>
                    Staff
                </a>
            </li>
            <li>
                <a href="manage_payments.php" class="nav-link-custom">
                    <i class="fas fa-money-bill me-2"></i>
                    Payments
                </a>
            </li>
            <li>
                <a href="manage_announcements.php" class="nav-link-custom active-link">
                    <i class="fas fa-bullhorn me-2"></i>
                    Announcements
                </a>
            </li>
            <li>
                <a href="manage_reports.php" class="nav-link-custom">
                    <i class="fas fa-chart-bar me-2"></i>
                    Reports
                </a>
            </li>
            <li>
                <a href="../logout.php" class="nav-link-custom">
                    <i class="fas fa-sign-out-alt me-2"></i>
                    Logout
                </a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    
    <div id="content">
        <div class="container-fluid">
            <!-- Display Messages -->
            <?php if ($success_msg): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($success_msg); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($error_msg): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error_msg); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <h2>Manage Announcements</h2>
            
            <!-- Add Announcement Form -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Add New Announcement</h5>
                </div>
                <div class="card-body">
                    <form method="POST" id="addAnnouncementForm">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label class="form-label">Title</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Content</label>
                            <textarea class="form-control" name="content" rows="3" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Announcement</button>
                    </form>
                </div>
            </div>

            <!-- List of Announcements -->
            <div class="card">
                <div class="card-header">
                    <h5>Existing Announcements</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Content</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($announcements as $announcement): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($announcement['id']); ?></td>
                                        <td><?php echo htmlspecialchars($announcement['title']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($announcement['content'], 0, 100)) . '...'; ?></td>
                                        <td><?php echo htmlspecialchars($announcement['status']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($announcement['created_at'])); ?></td>
                                        <td>
                                            <a href="view_announcement.php?id=<?php echo $announcement['id']; ?>" 
                                               class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <button class="btn btn-sm btn-primary edit-btn" 
                                                    data-id="<?php echo $announcement['id']; ?>"
                                                    data-title="<?php echo htmlspecialchars($announcement['title']); ?>"
                                                    data-content="<?php echo htmlspecialchars($announcement['content']); ?>"
                                                    data-status="<?php echo htmlspecialchars($announcement['status']); ?>">
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this announcement?');">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?php echo $announcement['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Announcement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="id" id="edit-id">
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" class="form-control" name="title" id="edit-title" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Content</label>
                        <textarea class="form-control" name="content" id="edit-content" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-control" name="status" id="edit-status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.edit-btn').forEach(button => {
    button.addEventListener('click', function() {
        const id = this.dataset.id;
        const title = this.dataset.title;
        const content = this.dataset.content;
        const status = this.dataset.status;

        document.getElementById('edit-id').value = id;
        document.getElementById('edit-title').value = title;
        document.getElementById('edit-content').value = content;
        document.getElementById('edit-status').value = status;

        new bootstrap.Modal(document.getElementById('editModal')).show();
    });
});
</script>
</body>
</html> 