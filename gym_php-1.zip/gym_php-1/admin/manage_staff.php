<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin


// Fetch all staff
$stmt = $conn->prepare("SELECT * FROM staff");
$stmt->execute();
$staff = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Staff</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="manage_members.php" class="text-white"><i class="fas fa-users me-2"></i>Manage Members</a>
            </li>
            <li>
                <a href="manage_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>Manage Plans</a>
            </li>
            <li class="active">
                <a href="manage_staff.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage Staff</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Manage Staff</h2>
            <a href="insert_staff.php" class="btn btn-primary mb-3"><i class="fas fa-plus me-2"></i>Add Staff</a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($staff as $staff_member): ?>
                        <tr>
                            <td><?php echo $staff_member['staff_id']; ?></td>
                            <td><?php echo $staff_member['first_name']; ?></td>
                            <td><?php echo $staff_member['last_name']; ?></td>
                            <td><?php echo $staff_member['email']; ?></td>
                            <td><?php echo $staff_member['phone']; ?></td>
                            <td><?php echo $staff_member['role']; ?></td>
                            <td>
                                <a href="update_staff.php?id=<?php echo $staff_member['staff_id']; ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                                <a href="delete_staff.php?id=<?php echo $staff_member['staff_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 