<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin


// Fetch data for charts
$stmt = $conn->prepare("SELECT 
    COUNT(*) AS total_users,
    (SELECT COUNT(*) FROM staff) AS total_staff,
    (SELECT SUM(amount) FROM payments) AS total_payments,
    (SELECT COUNT(*) FROM payments WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AS monthly_payments,
    (SELECT COUNT(*) FROM members WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AS new_members
    FROM members");
$stmt->execute();
$reportData = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reports</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="manage_members.php" class="text-white"><i class="fas fa-users me-2"></i>Manage Members</a>
            </li>
            <li>
                <a href="manage_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>Manage Plans</a>
            </li>
            <li>
                <a href="manage_staff.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage Staff</a>
            </li>
            <li>
                <a href="manage_payments.php" class="text-white"><i class="fas fa-money-bill-wave me-2"></i>Manage Payments</a>
            </li>
            <li class="active">
                <a href="manage_reports.php" class="text-white"><i class="fas fa-chart-bar me-2"></i>Manage Reports</a>
            </li>
            <li>
                <a href="manage_member_reports.php" class="text-white"><i class="fas fa-file-alt me-2"></i>Member Progress</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>System Reports</h2>
            
            <!-- Chart Section -->
            <div class="row mt-4">
                <!-- Members Growth Chart -->
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h4>Members Growth</h4>
                        </div>
                        <div class="card-body">
                            <canvas id="membersChart" style="height: 300px;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Payments Overview Chart -->
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h4>Payments Overview</h4>
                        </div>
                        <div class="card-body">
                            <canvas id="paymentsChart" style="height: 300px;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- System Statistics Chart -->
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h4>System Statistics</h4>
                        </div>
                        <div class="card-body">
                            <canvas id="systemStatsChart" style="height: 300px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });

    // Members Growth Chart
    const membersCtx = document.getElementById('membersChart').getContext('2d');
    new Chart(membersCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
            datasets: [{
                label: 'New Members',
                data: [12, 19, 3, 5, 2, 3, 15],
                borderColor: 'rgba(75, 192, 192, 1)',
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Payments Overview Chart
    const paymentsCtx = document.getElementById('paymentsChart').getContext('2d');
    new Chart(paymentsCtx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
            datasets: [{
                label: 'Payments',
                data: [1200, 1900, 300, 500, 200, 300, 1500],
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // System Statistics Chart
    const systemStatsCtx = document.getElementById('systemStatsChart').getContext('2d');
    new Chart(systemStatsCtx, {
        type: 'doughnut',
        data: {
            labels: ['Total Users', 'Total Staff', 'Total Payments'],
            datasets: [{
                label: 'System Statistics',
                data: [
                    <?php echo $reportData['total_users']; ?>,
                    <?php echo $reportData['total_staff']; ?>,
                    <?php echo $reportData['total_payments']; ?>
                ],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(75, 192, 192, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });
</script>
</body>
</html> 