<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Fetch member progress data with percentage
$stmt = $conn->prepare("
    SELECT 
        m.member_id,
        m.first_name,
        m.last_name,
        p.plan_name,
        COUNT(DISTINCT w.workout_id) AS completed_workouts,
        (SELECT COUNT(*) FROM workouts WHERE plan_id = m.plan_id) AS total_workouts,
        CASE
            WHEN (SELECT COUNT(*) FROM workouts WHERE plan_id = m.plan_id) = 0 THEN 0
            ELSE ROUND((COUNT(DISTINCT w.workout_id) / (SELECT COUNT(*) FROM workouts WHERE plan_id = m.plan_id)) * 100)
        END AS progress_percentage
    FROM members m
    LEFT JOIN workout_logs w ON m.member_id = w.member_id
    LEFT JOIN plans p ON m.plan_id = p.plan_id
    GROUP BY m.member_id
    ORDER BY progress_percentage DESC
");
$stmt->execute();
$memberProgress = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Progress</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- ... existing sidebar code ... -->

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Member Progress Report</h2>
            
            <!-- Progress Cards -->
            <div class="row mt-4">
                <?php foreach ($memberProgress as $member): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                                </h5>
                                <h6 class="card-subtitle mb-2 text-muted">
                                    <?php echo htmlspecialchars($member['plan_name']); ?>
                                </h6>
                                <div class="progress mb-3">
                                    <div class="progress-bar" 
                                         role="progressbar" 
                                         style="width: <?php echo $member['progress_percentage']; ?>%" 
                                         aria-valuenow="<?php echo $member['progress_percentage']; ?>" 
                                         aria-valuemin="0" 
                                         aria-valuemax="100">
                                        <?php echo $member['progress_percentage']; ?>%
                                    </div>
                                </div>
                                <p class="card-text">
                                    <i class="fas fa-check-circle text-success"></i> 
                                    Completed <?php echo $member['completed_workouts']; ?> of <?php echo $member['total_workouts']; ?> workouts
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle functionality
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html>