<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin


// Fetch all member progress reports
$stmt = $conn->prepare("
    SELECT mp.progress_id, m.username, mp.previous_height, mp.previous_weight, mp.height AS current_height, mp.weight AS current_weight, mp.progress_months, mp.report_date
    FROM member_progress mp
    JOIN members m ON mp.member_id = m.member_id
    ORDER BY mp.report_date DESC
");
$stmt->execute();
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Member Reports</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="manage_members.php" class="text-white"><i class="fas fa-users me-2"></i>Manage Members</a>
            </li>
            <li>
                <a href="manage_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>Manage Plans</a>
            </li>
            <li>
                <a href="manage_staff.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage Staff</a>
            </li>
            <li>
                <a href="manage_payments.php" class="text-white"><i class="fas fa-money-bill-wave me-2"></i>Manage Payments</a>
            </li>
            <li>
                <a href="manage_reports.php" class="text-white"><i class="fas fa-chart-bar me-2"></i>Manage Reports</a>
            </li>
            <li class="active">
                <a href="manage_member_reports.php" class="text-white"><i class="fas fa-file-alt me-2"></i>Member Progress</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Manage Member Progress Reports</h2>
            <div class="table-responsive mt-4">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Member Name</th>
                            <th>Previous Height (cm)</th>
                            <th>Previous Weight (kg)</th>
                            <th>Current Height (cm)</th>
                            <th>Current Weight (kg)</th>
                            <th>Progress Months</th>
                            <th>Report Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reports)): ?>
                            <tr>
                                <td colspan="7" class="text-center">No progress reports found.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($reports as $report): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($report['username']); ?></td>
                                    <td><?php echo htmlspecialchars($report['previous_height']); ?></td>
                                    <td><?php echo htmlspecialchars($report['previous_weight']); ?></td>
                                    <td><?php echo htmlspecialchars($report['current_height']); ?></td>
                                    <td><?php echo htmlspecialchars($report['current_weight']); ?></td>
                                    <td><?php echo htmlspecialchars($report['progress_months']); ?></td>
                                    <td><?php echo htmlspecialchars($report['report_date']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 