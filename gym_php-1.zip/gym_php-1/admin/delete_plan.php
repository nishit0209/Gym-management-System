<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Delete plan
if (isset($_GET['id'])) {
    $plan_id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM plans WHERE plan_id = ?");
    if ($stmt->execute([$plan_id])) {
        header('Location: manage_plans.php');
        exit();
    } else {
        echo "Failed to delete plan.";
    }
} else {
    header('Location: manage_plans.php');
    exit();
}
?> 