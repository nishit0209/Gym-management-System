<?php
session_start();
include '../includes/db.php';



// Initialize search term
$search_term = '';
$members = [];

// Check if search form is submitted
if (isset($_GET['search'])) {
    $search_term = trim($_GET['search']);
    
    // Fetch members filtered by name
    $stmt = $conn->prepare("SELECT * FROM members WHERE username LIKE :search ORDER BY username");
    $stmt->execute([':search' => '%' . $search_term . '%']);
    $members = $stmt->fetchAll();
} else {
    // Fetch all members if no search term
    $stmt = $conn->prepare("SELECT * FROM members ORDER BY username");
    $stmt->execute();
    $members = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Members</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li class="active">
                <a href="manage_members.php" class="text-white"><i class="fas fa-users me-2"></i>Manage Members</a>
            </li>
            <li>
                <a href="manage_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>Manage Plans</a>
            </li>
            <li>
                <a href="manage_staff.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage Staff</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Manage Members</h2>
            
            <!-- Search Form -->
            <form method="GET" class="mb-3">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Search by name" value="<?php echo htmlspecialchars($search_term); ?>">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
                    <?php if ($search_term): ?>
                        <a href="manage_members.php" class="btn btn-secondary"><i class="fas fa-times"></i> Clear</a>
                    <?php endif; ?>
                </div>
            </form>

            <a href="insert_member.php" class="btn btn-primary mb-3"><i class="fas fa-plus me-2"></i>Add Member</a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($members) > 0): ?>
                        <?php foreach ($members as $member): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($member['member_id']); ?></td>
                                <td><?php echo htmlspecialchars($member['username']); ?></td>
                                <td><?php echo htmlspecialchars($member['email']); ?></td>
                                <td><?php echo htmlspecialchars($member['phone']); ?></td>
                                <td>
                                    <a href="update_member.php?id=<?php echo $member['member_id']; ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                                    <a href="delete_member.php?id=<?php echo $member['member_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">No members found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 