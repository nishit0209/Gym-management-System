<?php
session_start();
include '../includes/db.php';

// Check if admin is logged in

// Get class ID
$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: schedule.php");
    exit();
}

// Delete class
try {
    $stmt = $conn->prepare("DELETE FROM schedule WHERE id = ?");
    $stmt->execute([$id]);

    $_SESSION['success'] = "Class deleted successfully!";
} catch (PDOException $e) {
    $_SESSION['error'] = "Error deleting class: " . $e->getMessage();
}

header("Location: schedule.php");
exit();
?> 