<?php
session_start();
include '../includes/db.php';

// Check if admin is logged in


// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $day = $_POST['day'];
        $start_time = $_POST['start_time'];
        $workout = $_POST['workout'];
        $exercise = $_POST['exercise'];
        $reps = $_POST['reps'];
        $diet=$_POST['diet'];
        

        // Insert new schedule
        $stmt = $conn->prepare("
            INSERT INTO schedule (day, start_time, workout, exercise, reps,diet)
            VALUES (:day, :start_time, :workout, :exercise, :reps, :diet)
        ");
        $stmt->execute([
            ':day' => $day,
            ':start_time' => $start_time,
            ':workout' => $workout,
            ':exercise' => $exercise,
            ':reps' => $reps,
            ':diet' => $diet
        ]);

        $_SESSION['success'] = "Class added successfully!";
        header("Location: schedule.php");
        exit();
    } catch (PDOException $e) {
        $error = "Error adding class: " . $e->getMessage();
    }
}

// Fetch schedule data
try {
    $stmt = $conn->prepare("SELECT * FROM schedule ORDER BY day, start_time");
    $stmt->execute();
    $schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error fetching schedule: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Schedule - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .schedule-table {
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .schedule-table th {
            background-color: #0d6efd;
            color: white;
            font-weight: 600;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Dashboard</h3>
        </div>
        <ul class="list-unstyled components">
            <li class="active">
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="manage_members.php" class="text-white"><i class="fas fa-users me-2"></i>Manage Members</a>
            </li>
            <li>
                <a href="manage_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>Manage Plans</a>
            </li>
            <li>
                <a href="manage_staff.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage Staff</a>
            </li>
            <li>
                <a href="manage_payments.php" class="text-white"><i class="fas fa-user-tie me-2"></i>Manage payment</a>
            </li>
            <li class="active">
                <a href="manage_reports.php" class="text-white"><i class="fas fa-chart-bar me-2"></i>Manage Reports</a>
            </li>
            <li class="active">
                <a href="view_announcement.php" class="text-white"><i class="fa fa-bullhorn me-2"></i>Annoucement</a>
            </li>
            <li class="active">
                <a href="schedule.php" class="text-white"><i class="fa fa-calendar me-2"></i>Schedule</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>


    <div class="container my-5">
        <h1 class="mb-4">Manage Class Schedule</h1>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Add Class Form -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Add New Class</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Day</label>
                            <select name="day" class="form-select" required>
                                <option value="Monday">Monday</option>
                                <option value="Tuesday">Tuesday</option>
                                <option value="Wednesday">Wednesday</option>
                                <option value="Thursday">Thursday</option>
                                <option value="Friday">Friday</option>
                                <option value="Saturday">Saturday</option>
                                <option value="Sunday">Sunday</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Start Time</label>
                            <input type="time" name="start_time" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Workout</label>
                            <input type="text" name="workout" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Exercise</label>
                            <input type="text" name="exercise" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">reps</label>
                            <input type="text" name="reps" class="form-control" min="15" max="180" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">diet</label>
                            <input type="text" name="diet" class="form-control" min="1" max="50" required>
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary">Add Class</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Schedule Table -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Current Schedule</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table schedule-table">
                        <thead>
                            <tr>
                                <th>Day</th>
                                <th>Time</th>
                                <th>Workout</th>
                                <th>Exercise</th>
                                <th>Reps</th>
                                <th>Diet</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($schedule)): ?>
                                <?php foreach ($schedule as $class): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($class['day']); ?></td>
                                        <td><?php echo date('h:i A', strtotime($class['start_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($class['workout']); ?></td>
                                        <td><?php echo htmlspecialchars($class['exercise']); ?></td>
                                        <td><?php echo htmlspecialchars($class['reps']); ?> mins</td>
                                        <td><?php echo htmlspecialchars($class['diet']); ?></td>
                                        <td>
                                            <a href="edit_schedule.php?id=<?php echo $class['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <a href="delete_schedule.php?id=<?php echo $class['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">No classes scheduled</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 