<?php
session_start();
include '../includes/db.php';


// Check if announcement ID exists in URL
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "No announcement ID specified.";
    header('Location: manage_announcements.php');
    exit;
}

// Validate if ID is numeric
$id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
if ($id === false) {
    $_SESSION['error'] = "Invalid announcement ID.";
    header('Location: manage_announcements.php');
    exit;
}

// Fetch the specific announcement
try {
    $stmt = $conn->prepare("SELECT * FROM announcements WHERE id = ?");
    $stmt->execute([$id]);
    $announcement = $stmt->fetch();

    // If announcement doesn't exist, redirect
    if (!$announcement) {
        $_SESSION['error'] = "Announcement not found.";
        header('Location: manage_announcements.php');
        exit;
    }
} catch (PDOException $e) {
    $_SESSION['error'] = "Database error: " . $e->getMessage();
    header('Location: manage_announcements.php');
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Announcement - Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Custom CSS for vertical navbar */
        .wrapper {
            display: flex;
            width: 100%;
        }

        #sidebar {
            min-width: 250px;
            max-width: 250px;
            min-height: 100vh;
            transition: all 0.3s;
        }

        #sidebar.active {
            margin-left: -250px;
        }

        #sidebar .sidebar-header {
            padding: 20px;
            background: #343a40;
        }

        #sidebar ul.components {
            padding: 20px 0;
        }

        #sidebar ul li a {
            padding: 10px 20px;
            font-size: 1.1em;
            display: block;
            text-decoration: none;
            transition: all 0.3s;
        }

        #sidebar ul li a:hover {
            background: #495057;
        }

        #content {
            width: 100%;
            padding: 20px;
        }

        @media (max-width: 768px) {
            #sidebar {
                margin-left: -250px;
            }
            #sidebar.active {
                margin-left: 0;
            }
        }

        .announcement-details {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
        }

        .nav-link-custom {
            color: #fff;
            position: relative;
            display: flex;
            align-items: center;
            border-radius: 5px;
            margin: 4px 10px;
        }

        .nav-link-custom:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .nav-link-custom i {
            width: 24px;
            text-align: center;
        }

        .active-link {
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Admin Panel</h3>
        </div>

        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="nav-link-custom">
                    <i class="fas fa-home me-2"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="manage_members.php" class="nav-link-custom">
                    <i class="fas fa-users me-2"></i>
                    Members
                </a>
            </li>
            <li>
                <a href="manage_plans.php" class="nav-link-custom">
                    <i class="fas fa-list-alt me-2"></i>
                    Plans
                </a>
            </li>
            <li>
                <a href="manage_staff.php" class="nav-link-custom">
                    <i class="fas fa-user-tie me-2"></i>
                    Staff
                </a>
            </li>
            <li>
                <a href="manage_payments.php" class="nav-link-custom">
                    <i class="fas fa-money-bill me-2"></i>
                    Payments
                </a>
            </li>
            <li>
                <a href="manage_announcements.php" class="nav-link-custom active-link">
                    <i class="fas fa-bullhorn me-2"></i>
                    Announcements
                </a>
            </li>
            <li>
                <a href="manage_reports.php" class="nav-link-custom">
                    <i class="fas fa-chart-bar me-2"></i>
                    Reports
                </a>
            </li>
            <li>
                <a href="../logout.php" class="nav-link-custom">
                    <i class="fas fa-sign-out-alt me-2"></i>
                    Logout
                </a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
                <span class="ms-3">View Announcement</span>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="manage_announcements.php">Announcements</a></li>
                            <li class="breadcrumb-item active">View Announcement</li>
                        </ol>
                    </nav>

                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">
                                <i class="fas fa-bullhorn me-2"></i>
                                Announcement Details
                            </h5>
                            <div>
                                <a href="manage_announcements.php" class="btn btn-secondary btn-sm">
                                    <i class="fas fa-arrow-left me-1"></i> Back
                                </a>
                                <a href="manage_announcements.php?edit=<?php echo $announcement['id']; ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit me-1"></i> Edit
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="announcement-details">
                                <div class="row mb-4">
                                    <div class="col-md-8">
                                        <h3><?php echo htmlspecialchars($announcement['title']); ?></h3>
                                    </div>
                                    <div class="col-md-4 text-md-end">
                                        <span class="badge bg-<?php echo $announcement['status'] === 'active' ? 'success' : 'warning'; ?>">
                                            <?php echo ucfirst($announcement['status']); ?>
                                        </span>
                                    </div>
                                </div>

                                <div class="announcement-meta mb-4">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar me-1"></i> Created: <?php echo date('F d, Y h:i A', strtotime($announcement['created_at'])); ?>
                                    </small>
                                    <br>
                                    <small class="text-muted">
                                        <i class="fas fa-clock me-1"></i> Last Updated: <?php echo date('F d, Y h:i A', strtotime($announcement['updated_at'])); ?>
                                    </small>
                                </div>

                                <div class="announcement-content">
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <?php echo nl2br(htmlspecialchars($announcement['content'])); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Comments Section (Optional) -->
                    <div class="card mt-4">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="fas fa-comments me-2"></i>Actions History</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Action</th>
                                            <th>Status Change</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($announcement['created_at'])); ?></td>
                                            <td>Announcement Created</td>
                                            <td>Set to <?php echo $announcement['status']; ?></td>
                                        </tr>
                                        <?php if ($announcement['updated_at'] != $announcement['created_at']): ?>
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($announcement['updated_at'])); ?></td>
                                            <td>Announcement Updated</td>
                                            <td>Current status: <?php echo $announcement['status']; ?></td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 