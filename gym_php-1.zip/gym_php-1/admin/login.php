<?php
session_start();

// Database connection
$host = 'localhost';
$dbname = 'gym_management';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if 'username' and 'password' keys exist in $_POST
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Validate inputs
    $errors = [];
    if (empty($username)) {
        $errors[] = 'Username is required';
    }
    if (empty($password)) {
        $errors[] = 'Password is required';
    }

    if (empty($errors)) {
        try {
            // Fetch admin from database using username
            $stmt = $pdo->prepare("SELECT admin_id, username, password_hash FROM admins WHERE username = ?");
            $stmt->execute([$username]);
            $admin = $stmt->fetch();

            if ($admin && password_verify($password, $admin['password_hash'])) {
                // Login successful
                $_SESSION['admin_id'] = $admin['admin_id'];
                $_SESSION['username'] = $admin['username'];

                // Redirect to admin dashboard
                header('Location: dashboard.php');
                exit;
            } else {
                $errors[] = 'Invalid username or password';
            }
        } catch (PDOException $e) {
            $errors[] = 'Login failed: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #111;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #7b90a4;
        }
        .container {
            margin-top: 45px;
            width: 100%;
            max-width: 450px;
            padding: 25px;
            background:rgba(237, 204, 204, 0.82);
            border-radius: 15px;
            box-shadow: 10px 10px 10px rgba(94, 91, 91, 0.76);
            text-align: center;
        }
        h1 {
            font-size: 2rem;
            margin-bottom: 20px;
            text-shadow: 2px 2px rgba(128, 124, 124, 0.76);
        }
        .form-group {
            position: relative;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            background: white;
            border-radius: 5px;
            overflow: hidden;
        }
        .form-group i {
            padding: 10px;
            background:rgba(255, 0, 0, 0.57);
            color: black;
            min-width: 40px;
            text-align: center;
            border-radius: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 1rem;
            border: none;
            outline: none;
        }
        .btn {
            width: 100%;
            padding: 10px;
            font-size: 1.2rem;
            background:rgba(162, 0, 0, 0.7);
            color: black;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background:rgba(255, 0, 0, 0.62);
        }
        @media (max-width: 480px) {
            h1 {
                font-size: 1.8rem;
            }
            .form-group input {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>LOGIN</h1>
        <form action="login.php" method="POST">
            <div class="form-group">
                <i class="fas fa-user"></i>
                <input type="text" placeholder="Username" id="username" name="username" required>
            </div>
            <div class="form-group">
                <i class="fas fa-lock"></i>
                <input type="password" placeholder="Password" id="password" name="password" required>
            </div>
            <p>Forget Password <a href="reset_password.php">Forget Password</a></p>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>
</body>
</html>