<?php
session_start();
include 'includes/db.php';

try {
    // Check if form was submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Verify member is logged in
        if (!isset($_SESSION['member_id'])) {
            throw new Exception("Please login to continue");
        }

        // Get and validate member_id from session
        $member_id = $_SESSION['member_id'];
        if (empty($member_id) || !is_numeric($member_id)) {
            throw new Exception("Invalid member ID. Please login again.");
        }

        // Get and validate other form data
        $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : null;
        $amount = floatval($_POST['amount']);
        $payment_method = $_POST['payment_method'];
        
        // Validate amount
        if ($amount <= 0) {
            throw new Exception("Invalid amount");
        }

        // Set payment details
        $payment_status = 'completed';
        $payment_date = date('Y-m-d H:i:s');
        
        // Get payment details based on method
        $payment_details = [];
        if ($payment_method === 'credit_card') {
            $payment_details = [
                'card_number' => substr($_POST['card_number'], -4),
                'card_holder' => $_POST['card_holder'],
                'expiry' => $_POST['card_expiry']
            ];
        } else if ($payment_method === 'upi') {
            $payment_details = [
                'upi_id' => $_POST['upi_id']
            ];
        } else if ($payment_method === 'cash') {
            $payment_details = [
                'reference' => uniqid('CASH-')
            ];
        }

        // Begin transaction
        $conn->beginTransaction();

        // Insert payment record
        $sql = "INSERT INTO payments (member_id, plan_id, amount, payment_method, payment_details, payment_status, payment_date) 
                VALUES (:member_id, :plan_id, :amount, :payment_method, :payment_details, :payment_status, :payment_date)";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':member_id' => $member_id,
            ':plan_id' => $plan_id,
            ':amount' => $amount,
            ':payment_method' => $payment_method,
            ':payment_details' => json_encode($payment_details),
            ':payment_status' => $payment_status,
            ':payment_date' => $payment_date
        ]);

        // If this is a plan purchase, create subscription
        if ($plan_id) {
            // Get plan details
            $stmt = $conn->prepare("SELECT * FROM plans WHERE plan_id = ?");
            $stmt->execute([$plan_id]);
            $plan = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($plan) {
                $start_date = date('Y-m-d');
                $end_date = date('Y-m-d', strtotime("+{$plan['duration']} months"));

                // Insert subscription
                $sql = "INSERT INTO subscriptions (member_id, plan_id, start_date, end_date, status) 
                       VALUES (:member_id, :plan_id, :start_date, :end_date, :status)";
                
                $stmt = $conn->prepare($sql);
                $stmt->execute([
                    ':member_id' => $member_id,
                    ':plan_id' => $plan_id,
                    ':start_date' => $start_date,
                    ':end_date' => $end_date,
                    ':status' => 'active'
                ]);
            }
        }

        // Commit the transaction
        $conn->commit();
        $_SESSION['payment_data'] = [
            'amount' => $amount,
            'payment_method' => $payment_method,
            'payment_details' => $payment_details,
            'plan_name' => $plan['name'] ?? 'Custom Payment',
            'payment_date' => $payment_date
        ];

        // Store success message
        $_SESSION['success'] = "Payment processed successfully!";
        
        // Redirect to confirmation page
        header("Location: payment_confirmation.php");
        exit();

    } else {
        throw new Exception("Invalid request method");
    }

} catch (Exception $e) {
    // Rollback transaction if error occurs
    if ($conn && $conn->inTransaction()) {
        $conn->rollBack();
    }
    
    // Log the error for debugging
    error_log("Payment Error: " . $e->getMessage());
    
    $_SESSION['error'] = "Payment failed: " . $e->getMessage();
    header("Location: payment.php");
    exit();
}
?> 