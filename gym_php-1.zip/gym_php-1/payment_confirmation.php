<?php
session_start();

// Check if payment data exists in session
if (!isset($_SESSION['payment_data'])) {
    $_SESSION['error'] = "No payment data found. Please complete the payment process.";
    header("Location: payment.php");
    exit();
}

// Get payment data from session
$payment_data = $_SESSION['payment_data'];

// Extract payment details with null coalescing operator for safety
$amount = $payment_data['amount'] ?? 0.00;
$payment_method = $payment_data['payment_method'] ?? 'Unknown';
$payment_details = $payment_data['payment_details'] ?? [];
$plan_name = $payment_data['plan_name'] ?? 'Custom Payment';
$payment_date = $payment_data['payment_date'] ?? date('Y-m-d H:i:s');


// Clear the payment data from session
unset($_SESSION['payment_data']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Confirmation - Gym Management System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-check-circle text-success" style="font-size: 48px;"></i>
                    <h3 class="mt-3">Payment Successful!</h3>
                    
                    <div class="mt-4 text-start">
                        <p><strong>Payment Date:</strong> <?php echo date('M d, Y h:i A', strtotime($payment_date)); ?></p>
                        <p><strong>Plan Name:</strong> <?php echo htmlspecialchars($plan_name); ?></p>
                        <p><strong>Amount Paid:</strong> ₹<?php echo number_format($amount, 2); ?></p>
                        <p><strong>Payment Method:</strong> <?php echo htmlspecialchars(ucfirst($payment_method)); ?></p>
                        
                        <?php if (!empty($payment_details)): ?>
                            <div class="mt-3">
                                <h5>Payment Details:</h5>
                                <?php if ($payment_method === 'credit_card'): ?>
                                    <p>Card Holder: <?php echo htmlspecialchars($payment_details['card_holder'] ?? 'N/A'); ?></p>
                                    <p>Card Number: **** **** **** <?php echo htmlspecialchars($payment_details['card_number'] ?? ''); ?></p>
                                    <p>Expiry: <?php echo htmlspecialchars($payment_details['expiry'] ?? 'N/A'); ?></p>
                                <?php elseif ($payment_method === 'upi'): ?>
                                    <p>UPI ID: <?php echo htmlspecialchars($payment_details['upi_id'] ?? 'N/A'); ?></p>
                                <?php elseif ($payment_method === 'cash'): ?>
                                    <p>Reference Number: <?php echo htmlspecialchars($payment_details['reference'] ?? 'N/A'); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="mt-4">
                        <a href="user/profile.php" class="btn btn-primary">Return to Dashboard</a>
                        <a href="#" class="btn btn-outline-secondary" onclick="window.print()">
                            <i class="fas fa-print me-2"></i>Print Receipt
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
// Clear the success message
unset($_SESSION['success']);
?>
</body>
</html> 