// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Add animations on scroll
window.addEventListener('scroll', () => {
    const features = document.querySelectorAll('.animate__animated');
    features.forEach(feature => {
        const featurePosition = feature.getBoundingClientRect().top;
        const screenPosition = window.innerHeight / 1.3;
        if (featurePosition < screenPosition) {
            feature.classList.add('animate__fadeIn');
        }
    });
});

// Add fade-in animation on scroll for footer
window.addEventListener('scroll', () => {
    const footer = document.querySelector('.footer');
    const footerPosition = footer.getBoundingClientRect().top;
    const screenPosition = window.innerHeight / 1.3;

    if (footerPosition < screenPosition) {
        footer.classList.add('animate__animated', 'animate__fadeInUp');
    }
});

// Add fade-in animation on scroll for navbar links
window.addEventListener('scroll', () => {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        const linkPosition = link.getBoundingClientRect().top;
        const screenPosition = window.innerHeight / 1.3;

        if (linkPosition < screenPosition) {
            link.classList.add('animate__fadeIn');
        }
    });
}); 