<?php
$page_title = "Gym Gallery";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../gallery/style.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="assets/images/logo.png" alt="Gym Logo" width="30" height="30" class="d-inline-block align-text-top">
            Gym Guru
        </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="../plans.php">Plans</a></li>
                <li class="nav-item"><a class="nav-link" href="gallery/index.php">Gallery</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            </ul>
        </div>
    </nav>

<!-- Gallery Section -->
<section class="gallery-section py-5">
    <div class="container">
        <h1 class="text-center mb-5 animate__animated animate__fadeIn">Our Gym Gallery</h1>
        <div class="row">
            <!-- Gym Image 1 -->
            <div class="col-md-6 col-lg-4 mb-4 animate__animated animate__fadeInLeft">
                <div class="card">
                    <img src="https://img.freepik.com/premium-photo/state-art-gym-with-modern-fitness-equipment_68708-12723.jpg" class="card-img-top" alt="Gym Image 1">
                    <div class="card-body">
                        <h5 class="card-title">State-of-the-Art Equipment</h5>
                        <p class="card-text">Our gym is equipped with the latest machines to help you achieve your fitness goals.</p>
                    </div>
                </div>
            </div>
            <!-- Gym Image 2 -->
            <div class="col-md-6 col-lg-4 mb-4 animate__animated animate__fadeInUp">
                <div class="card">
                    <img src="https://plus.unsplash.com/premium_photo-1661580282598-6883482b4c8e?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cGVyc29uYWwlMjB0cmFpbmVyfGVufDB8fDB8fHww" class="card-img-top" alt="Gym Image 2">
                    <div class="card-body">
                        <h5 class="card-title">Personal Training</h5>
                        <p class="card-text">Get personalized training sessions with our certified trainers.</p>
                    </div>
                </div>
            </div>
            <!-- Gym Image 3 -->
            <div class="col-md-6 col-lg-4 mb-4 animate__animated animate__fadeInRight">
                <div class="card">
                    <img src="../img/class-3.jpg" class="card-img-top" alt="Gym Image 3">
                    <div class="card-body">
                        <h5 class="card-title">Group Classes</h5>
                        <p class="card-text">Join our group classes for a fun and motivating workout experience.</p>
                    </div>
                </div>
            </div>
            <!-- Gym Image 4 -->
            <div class="col-md-6 col-lg-4 mb-4 animate__animated animate__fadeInLeft">
                <div class="card">
                    <img src="https://odessa.nemohotels.com/wp-content/uploads/2017/11/slim-relax-1.jpg" class="card-img-top" alt="Gym Image 4">
                    <div class="card-body">
                        <h5 class="card-title">Relaxation Zone</h5>
                        <p class="card-text">Unwind in our relaxation zone after an intense workout session.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
include '../includes/footer.php';
?> 