<?php
session_start();
include '../includes/db.php';

// Redirect if user is not logged in or not a staff member

// Fetch all member progress reports
$stmt = $conn->prepare("
    SELECT mp.progress_id, m.username, mp.previous_height, mp.previous_weight, mp.height AS current_height, mp.weight AS current_weight, mp.progress_months, mp.report_date
    FROM member_progress mp
    JOIN members m ON mp.member_id = m.member_id
    ORDER BY mp.report_date DESC
");
$stmt->execute();
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Reports</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Staff Dashboard</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="view_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>View Plans</a>
            </li>
            <li>
                <a href="show_users.php" class="text-white"><i class="fas fa-user-plus me-2"></i>Register Member</a>
            </li>
            <li class="active">
                <a href="view_member_reports.php" class="text-white"><i class="fas fa-chart-line me-2"></i>Member Reports</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid">
            <h2>Member Progress Reports</h2>
            <div class="table-responsive mt-4">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Member Name</th>
                            <th>Previous Height (cm)</th>
                            <th>Previous Weight (kg)</th>
                            <th>Current Height (cm)</th>
                            <th>Current Weight (kg)</th>
                            <th>Progress Months</th>
                            <th>Report Date</极客时间
                            <th>Report Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reports)): ?>
                            <tr>
                                <td colspan="7" class="text-center">No progress reports found.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($reports as $report): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($report['username']); ?></td>
                                    <td><?php echo htmlspecialchars($report['previous_height']); ?></td>
                                   <td><?php echo htmlspecialchars($report['previous_weight']); ?></td>
                                    <td><?php echo htmlspecialchars($report['current_height']); ?></td>
                                    <td><?php echo htmlspecialchars($report['current_weight']); ?></td>
                                    <td><?php echo htmlspecialchars($report['progress_months']); ?></td>
                                    <td><?php echo htmlspecialchars($report['report_date']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>
</body>
</html> 