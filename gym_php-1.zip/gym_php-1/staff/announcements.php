<?php
session_start();
include '../includes/db.php';

// Check if staff is logged in


// Fetch active announcements
try {
    $stmt = $conn->prepare("SELECT * FROM announcements WHERE status = 'active' ORDER BY created_at DESC");
    $stmt->execute();
    $announcements = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Error fetching announcements: " . $e->getMessage();
    $announcements = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Announcements - Gym Management System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .announcement-card {
            transition: transform 0.2s;
            margin-bottom: 20px;
            border-left: 4px solid #0d6efd;
        }
        
        .announcement-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .announcement-date {
            font-size: 0.9rem;
            color: #6c757d;
        }

        .new-badge {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .announcement-content {
            color: #555;
            line-height: 1.6;
            white-space: pre-line;
        }

        .priority-high {
            border-left-color: #dc3545;
        }

        .priority-medium {
            border-left-color: #ffc107;
        }

        .priority-low {
            border-left-color: #0d6efd;
        }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- Vertical Navbar -->
    <nav id="sidebar" class="bg-dark text-white">
        <div class="sidebar-header">
            <h3>Staff Dashboard</h3>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard.php" class="text-white"><i class="fas fa-home me-2"></i>Dashboard</a>
            </li>
            <li>
                <a href="view_plans.php" class="text-white"><i class="fas fa-list-alt me-2"></i>View Plans</a>
            </li>
            <li>
                <a href="show_users.php" class="text-white"><i class="fas fa-user-plus me-2"></i>Register Member</a>
            </li>
            <li>
                <a href="view_member_reports.php" class="text-white"><i class="fas fa-chart-line me-2"></i>Member Reports</a>
            </li>
            <li>
                <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </li>
        </ul>
    </nav>


    <!-- Main Content -->
    <div id="content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="fas fa-bullhorn me-2"></i>Staff Announcements</h1>
            </div>

            <?php if (empty($announcements)): ?>
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>No announcements available at this time.
                </div>
            <?php else: ?>
                <!-- Announcements Filter -->
                <div class="mb-4">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-primary active" data-filter="all">All</button>
                        <button type="button" class="btn btn-outline-primary" data-filter="new">New</button>
                    </div>
                </div>

                <!-- Announcements List -->
                <div class="row">
                    <?php foreach ($announcements as $announcement): 
                        $isNew = (time() - strtotime($announcement['created_at'])) < (7 * 24 * 60 * 60); // 7 days
                    ?>
                        <div class="col-12 announcement-item" data-category="<?php echo $isNew ? 'new' : 'old'; ?>">
                            <div class="card announcement-card">
                                <div class="card-body">
                                    <h5 class="card-title d-flex justify-content-between align-items-center">
                                        <?php echo htmlspecialchars($announcement['title']); ?>
                                        <?php if ($isNew): ?>
                                            <span class="badge bg-primary new-badge">New</span>
                                        <?php endif; ?>
                                    </h5>
                                    
                                    <p class="announcement-date mb-3">
                                        <i class="fas fa-calendar-alt me-1"></i>
                                        Posted: <?php echo date('F d, Y', strtotime($announcement['created_at'])); ?>
                                        <?php if ($announcement['updated_at'] != $announcement['created_at']): ?>
                                            <span class="ms-2">
                                                <i class="fas fa-edit me-1"></i>
                                                Updated: <?php echo date('F d, Y', strtotime($announcement['updated_at'])); ?>
                                            </span>
                                        <?php endif; ?>
                                    </p>
                                    
                                    <div class="announcement-content">
                                        <?php 
                                        // Convert URLs to clickable links and preserve line breaks
                                        $content = preg_replace('/(https?:\/\/[^\s]+)/', '<a href="$1" target="_blank">$1</a>', htmlspecialchars($announcement['content']));
                                        echo nl2br($content);
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JS for filtering -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Filter functionality
    const filterButtons = document.querySelectorAll('[data-filter]');
    const announcements = document.querySelectorAll('.announcement-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');

            const filterValue = this.getAttribute('data-filter');

            announcements.forEach(announcement => {
                if (filterValue === 'all') {
                    announcement.style.display = 'block';
                } else {
                    if (announcement.getAttribute('data-category') === filterValue) {
                        announcement.style.display = 'block';
                    } else {
                        announcement.style.display = 'none';
                    }
                }
            });
        });
    });
});
</script>
</body>
</html> 