<style>

</style>
<footer class="footer bg-dark text-white mt-5">
    <div class="container py-4">
        <div class="row">
            <!-- Quick Links -->
            <div class="col-md-4 mb-4">
                <h5 class="footer-heading">Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="footer-link">Home</a></li>
                    <li><a href="plans.php" class="footer-link">Plans</a></li>
                    <li><a href="gallery.php" class="footer-link">Gallery</a></li>
                    <li><a href="Schedule.php" class="footer-link">Schedule</a></li>
                    <li><a href="contact.php" class="footer-link">Contact</a></li>
                    <li><a href="about.php" class="footer-link">About</a></li>
                </ul>
            </div>

            <!-- Social Media Links -->
            <div class="col-md-4 mb-4">
                <h5 class="footer-heading">Follow Us</h5>
                <div class="social-icons">
                    <a href="#" class="social-icon"><i class="fab fa-facebook"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-youtube"></i></a>
                </div>
            </div>

            <!-- Contact Info -->
            <div class="col-md-4 mb-4">
                <h5 class="footer-heading">Contact Us</h5>
                <p><i class="fas fa-map-marker-alt me-2"></i>Gandhinagar</p>
                <p><i class="fas fa-phone me-2"></i>+91 8511317311</p>
                <p><i class="fas fa-envelope me-2"></i>gymguru@.com</p>
            </div>
        </div>
    </div>

    <!-- Copyright -->
    <!-- <div class="text-center py-3 bg-black">
        <p class="mb-0">&copy; 2023 Gym Name. All rights reserved.</p>
    </div> -->
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html> 
</html> 